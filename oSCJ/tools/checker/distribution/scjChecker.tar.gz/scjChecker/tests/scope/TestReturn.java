package scope;

public class TestReturn {
    public Object foo() {
        return null; // TODO revisit this
    }
}
