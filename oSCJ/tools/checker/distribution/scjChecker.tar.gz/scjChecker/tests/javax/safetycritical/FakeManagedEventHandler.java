package javax.safetycritical;

import javax.safetycritical.annotate.Level;
import javax.safetycritical.annotate.SCJAllowed;

@SCJAllowed(Level.LEVEL_1)
public class FakeManagedEventHandler {

    @SCJAllowed(Level.LEVEL_1)
    public FakeManagedEventHandler() {
        
    }
}
