package scjAllowed;

public class NoAllowed {
    public static void foo () {
        
    }
}
