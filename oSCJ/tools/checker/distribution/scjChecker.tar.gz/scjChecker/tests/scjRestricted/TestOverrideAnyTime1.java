package scjRestricted;

import javax.safetycritical.annotate.Restrict;
import javax.safetycritical.annotate.SCJRestricted;

public class TestOverrideAnyTime1 {
    @SCJRestricted(Restrict.ANY_TIME)
    public void foo() {
        
    }
}

class TestOverrideAnyTime1Helper extends TestOverrideAnyTime1 {
    @SCJRestricted(Restrict.ANY_TIME)
    public void foo() {
        
    }
}