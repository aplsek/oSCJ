package checkers.util.test;

import checkers.quals.*;

/** A supertype of SubQual. */
@TypeQualifier
@SubtypeOf( {} )
@DefaultQualifierInHierarchy
public @interface SuperQual { }
