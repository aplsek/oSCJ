package checkers.util.test;

import checkers.quals.*;

/** A subtype of SuperQual. */
@TypeQualifier
@SubtypeOf( SuperQual.class )
public @interface SubQual { }
