/**
 * Contains qualifiers for type annotations used by the IGJ checker.
 *
 * @see checkers.igj.IGJChecker
 *
 * @checker.framework.manual #igj-checker IGJ Checker
 */
package checkers.igj.quals;
