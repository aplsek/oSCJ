package checkers.util.test;

import checkers.quals.*;

@PolymorphicQualifier @TypeQualifier
public @interface PolyEncrypted {

}
