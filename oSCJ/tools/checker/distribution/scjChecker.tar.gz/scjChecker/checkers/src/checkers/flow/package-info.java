/**
 * Contains a generalized flow-sensitive qualifier inference that can be
 * employed by any checker.
 */
package checkers.flow;