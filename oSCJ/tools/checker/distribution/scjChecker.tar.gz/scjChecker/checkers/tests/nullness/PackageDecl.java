package foo.bar;

import checkers.nullness.quals.*;

class PackageDecl {

}