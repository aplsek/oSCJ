
class Addressable<T extends Addressable> implements Comparable<T> {
    public int compareTo(T t) { return 0; }
}
