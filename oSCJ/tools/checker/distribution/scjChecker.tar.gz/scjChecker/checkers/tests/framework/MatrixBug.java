import checkers.util.test.*;
import java.util.*;

public class MatrixBug {

    public char[][] chars = new char[][] {
        new char[] { '*', '*', '*' },
        new char[] { '*', '*', '*' }
    };
}
