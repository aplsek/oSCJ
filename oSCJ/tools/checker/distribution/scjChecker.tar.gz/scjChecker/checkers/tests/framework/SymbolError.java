import java.util.*;

class SymbolError {

    void test() {
        List<String> lst = new LinkedList<String>(null) {

        };
    }
}