import checkers.interning.quals.*;

import java.util.*;


public class Expressions {

    class A {
        B b;
    }
    class B {
        C c;
        D d() { return new D(); }
        Boolean bBoolean() { return true; }
    }
    class C {}
    class D {}

    public Boolean fieldThenMethod(A a) {
        Boolean temp = a.b.bBoolean();
        return temp;
    }

    class Foo {
        public @Interned Foo returnThis(@Interned Foo other) @Interned {
            if (other == this)
                return this;
            else
                return null;
        }
    }

    public @Interned Foo THEONE = new @Interned Foo();

    public boolean isItTheOne(Foo f) {
        return THEONE.equals(f);
    }

    // A warning when interned objects are compared via .equals helps me in
    // determining whether it is a good idea to convert a given class or
    // reference to @Interned -- I can see whether there are places that it
    // is compared with .equals, which I might need to examine.
    public boolean dontUseEqualsMethod(@Interned Foo f1, @Interned Foo f2) {
        return f1.equals(f2);
    }

}
