import checkers.util.test.*;
import java.util.*;

// TODO: update the ref output with the expected result (minus the crash)
public class MissingSymbolCrash {
    public void test() {
        lst.add(s);
    }
}
