import checkers.util.test.*;
import java.util.*;

public class AnnotatedVoidMethod {
    public @Odd void method() {
        return;
    }
}
