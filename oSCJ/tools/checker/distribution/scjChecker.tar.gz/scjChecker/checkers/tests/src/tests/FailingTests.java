package tests;

import org.junit.Test;

public class FailingTests {
    NullnessTest nullnessTest = new NullnessTest();
    IGJTest igjTest = new IGJTest();
    InterningTest interningTests = new InterningTest();
    JavariTest javariTests = new JavariTest();
}
