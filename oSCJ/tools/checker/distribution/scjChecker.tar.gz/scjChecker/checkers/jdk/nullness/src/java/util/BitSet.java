package java.util;
import checkers.nullness.quals.*;
@checkers.quals.DefaultQualifier("checkers.nullness.quals.NonNull")

public class BitSet implements Cloneable, java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public BitSet() { throw new RuntimeException("skeleton method"); }
  public BitSet(int a1) { throw new RuntimeException("skeleton method"); }
  public void flip(int a1) { throw new RuntimeException("skeleton method"); }
  public void flip(int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public void set(int a1) { throw new RuntimeException("skeleton method"); }
  public void set(int a1, boolean a2) { throw new RuntimeException("skeleton method"); }
  public void set(int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public void set(int a1, int a2, boolean a3) { throw new RuntimeException("skeleton method"); }
  public void clear(int a1) { throw new RuntimeException("skeleton method"); }
  public void clear(int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public void clear() { throw new RuntimeException("skeleton method"); }
  public boolean get(int a1) { throw new RuntimeException("skeleton method"); }
  public java.util.BitSet get(int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public int nextSetBit(int a1) { throw new RuntimeException("skeleton method"); }
  public int nextClearBit(int a1) { throw new RuntimeException("skeleton method"); }
  public int length() { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty() { throw new RuntimeException("skeleton method"); }
  public boolean intersects(java.util.BitSet a1) { throw new RuntimeException("skeleton method"); }
  public int cardinality() { throw new RuntimeException("skeleton method"); }
  public void and(java.util.BitSet a1) { throw new RuntimeException("skeleton method"); }
  public void or(java.util.BitSet a1) { throw new RuntimeException("skeleton method"); }
  public void xor(java.util.BitSet a1) { throw new RuntimeException("skeleton method"); }
  public void andNot(java.util.BitSet a1) { throw new RuntimeException("skeleton method"); }
  public int hashCode() { throw new RuntimeException("skeleton method"); }
  public int size() { throw new RuntimeException("skeleton method"); }
  public boolean equals(@Nullable java.lang.Object a1) { throw new RuntimeException("skeleton method"); }
  public java.lang.String toString() { throw new RuntimeException("skeleton method"); }
  public Object clone() { throw new RuntimeException("skeleton method"); }
}
