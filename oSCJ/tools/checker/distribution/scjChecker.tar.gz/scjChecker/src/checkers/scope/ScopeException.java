package checkers.scope;

public class ScopeException extends Exception {
    public ScopeException(String msg) {
        super(msg);
    }
}
