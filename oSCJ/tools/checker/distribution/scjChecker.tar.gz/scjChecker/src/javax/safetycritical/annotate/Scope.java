package javax.safetycritical.annotate;

public @interface Scope {
	public String value();
}
