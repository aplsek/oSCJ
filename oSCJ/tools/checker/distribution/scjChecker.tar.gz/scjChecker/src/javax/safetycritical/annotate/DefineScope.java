package javax.safetycritical.annotate;

public @interface DefineScope {
    public String name();
    public String parent();
}
