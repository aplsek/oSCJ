package javax.safetycritical.annotate;

public @interface RunsIn {
	public String value();
}
